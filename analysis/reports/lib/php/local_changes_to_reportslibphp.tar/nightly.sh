#!/bin/bash

cd /var/www/app/suma/analysis/reports/lib/php/
/usr/bin/php nightlyEmail.php